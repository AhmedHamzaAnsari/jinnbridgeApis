<?php

// Database connection settings
$servername = "localhost"; // Change this if your MySQL server is hosted elsewhere
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$database = "hascol"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the POST data
    $customer_id = $_POST['customer_id'];
    $name = $_POST['name'];
    $balance = $_POST['balance'];
    $lastbalance = $_POST['lastbalance'];

    // Prepare an SQL statement to insert data into the table
    $sql = "INSERT INTO customer_bal (customer_id, name, balance, lastbalance) VALUES (?, ?, ?, ?) 
    ON DUPLICATE KEY UPDATE 
    name = VALUES(name), 
    balance = VALUES(balance), 
    lastbalance = VALUES(lastbalance)";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind parameters to the statement
    $stmt->bind_param("ssss", $customer_id, $name, $balance, $lastbalance);
    
    // Execute the statement
    if ($stmt->execute()) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
